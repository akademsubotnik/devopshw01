"""Module providingFunction printing hello world."""

# file: hello_world.py
print("Hello, World!")
